
此目录下文件为伪静态规则，请根据自身应用环境拷贝重写规则到根目录。

1、Apache环境使用.htaccess，同时在规则中有两种情况，请注意；

2、IIS7+环境使用web.config，IIS6请自行百度；

3、Nginx请根据手册修改环境，也可百度“nginx 隐藏index.php”；